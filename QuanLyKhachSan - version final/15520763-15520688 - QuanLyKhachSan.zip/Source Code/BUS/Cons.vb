﻿Public Class Cons

#Region "Properties"

    'phòng mặc định trống namTinhTrang năm khi tạo mới phòng, 1 năm = 365 ngày
    Public Shared ReadOnly Property namTinhTrang() As Integer
        Get
            Return 3
        End Get
    End Property

#End Region

End Class
