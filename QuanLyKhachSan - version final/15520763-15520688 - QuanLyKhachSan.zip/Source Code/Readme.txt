﻿- Khởi t?o các table và stored procedure du?c vi?t trong file sqlQuanLyKhachSan.sql
- Thay d?i chu?i k?t n?i d?n co s? d? li?u trong file ConnectionString.xml
- Ch?y chuong trình