﻿Namespace ThayDoiQuyDinh
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class frmThayDoiQuyDinh
        Inherits System.Windows.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
            Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
            Me.GroupBox1 = New System.Windows.Forms.GroupBox()
            Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
            Me.txtBoxTiLePhuThu = New System.Windows.Forms.TextBox()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.txtBoxSoKhachToiDa = New System.Windows.Forms.TextBox()
            Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
            Me.btnCapNhat = New System.Windows.Forms.Button()
            Me.TableLayoutPanel1.SuspendLayout()
            Me.TableLayoutPanel2.SuspendLayout()
            Me.GroupBox1.SuspendLayout()
            Me.TableLayoutPanel3.SuspendLayout()
            Me.TableLayoutPanel4.SuspendLayout()
            Me.SuspendLayout()
            '
            'TableLayoutPanel1
            '
            Me.TableLayoutPanel1.ColumnCount = 1
            Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
            Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 1)
            Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel4, 0, 2)
            Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
            Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
            Me.TableLayoutPanel1.RowCount = 4
            Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.5!))
            Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
            Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.0!))
            Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
            Me.TableLayoutPanel1.Size = New System.Drawing.Size(1296, 725)
            Me.TableLayoutPanel1.TabIndex = 0
            '
            'TableLayoutPanel2
            '
            Me.TableLayoutPanel2.ColumnCount = 3
            Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
            Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
            Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
            Me.TableLayoutPanel2.Controls.Add(Me.GroupBox1, 1, 0)
            Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
            Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 129)
            Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
            Me.TableLayoutPanel2.RowCount = 1
            Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
            Me.TableLayoutPanel2.Size = New System.Drawing.Size(1290, 392)
            Me.TableLayoutPanel2.TabIndex = 0
            '
            'GroupBox1
            '
            Me.GroupBox1.BackColor = System.Drawing.Color.DeepSkyBlue
            Me.GroupBox1.Controls.Add(Me.TableLayoutPanel3)
            Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.GroupBox1.Location = New System.Drawing.Point(261, 3)
            Me.GroupBox1.Name = "GroupBox1"
            Me.GroupBox1.Padding = New System.Windows.Forms.Padding(10)
            Me.GroupBox1.Size = New System.Drawing.Size(768, 386)
            Me.GroupBox1.TabIndex = 0
            Me.GroupBox1.TabStop = False
            Me.GroupBox1.Text = "Quy Định Khách Sạn"
            '
            'TableLayoutPanel3
            '
            Me.TableLayoutPanel3.ColumnCount = 2
            Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
            Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
            Me.TableLayoutPanel3.Controls.Add(Me.txtBoxTiLePhuThu, 1, 1)
            Me.TableLayoutPanel3.Controls.Add(Me.Label1, 0, 0)
            Me.TableLayoutPanel3.Controls.Add(Me.Label2, 0, 1)
            Me.TableLayoutPanel3.Controls.Add(Me.txtBoxSoKhachToiDa, 1, 0)
            Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
            Me.TableLayoutPanel3.Location = New System.Drawing.Point(10, 52)
            Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(10)
            Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
            Me.TableLayoutPanel3.RowCount = 2
            Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
            Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
            Me.TableLayoutPanel3.Size = New System.Drawing.Size(748, 324)
            Me.TableLayoutPanel3.TabIndex = 0
            '
            'txtBoxTiLePhuThu
            '
            Me.txtBoxTiLePhuThu.Dock = System.Windows.Forms.DockStyle.Top
            Me.txtBoxTiLePhuThu.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtBoxTiLePhuThu.Location = New System.Drawing.Point(414, 177)
            Me.txtBoxTiLePhuThu.Margin = New System.Windows.Forms.Padding(40, 15, 40, 15)
            Me.txtBoxTiLePhuThu.Name = "txtBoxTiLePhuThu"
            Me.txtBoxTiLePhuThu.Size = New System.Drawing.Size(294, 34)
            Me.txtBoxTiLePhuThu.TabIndex = 3
            Me.txtBoxTiLePhuThu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label1.Location = New System.Drawing.Point(15, 15)
            Me.Label1.Margin = New System.Windows.Forms.Padding(15)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(344, 132)
            Me.Label1.TabIndex = 0
            Me.Label1.Text = "Số Khách Tối Đa:"
            Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
            Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label2.Location = New System.Drawing.Point(15, 177)
            Me.Label2.Margin = New System.Windows.Forms.Padding(15)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(344, 132)
            Me.Label2.TabIndex = 1
            Me.Label2.Text = "Tỉ Lệ Phụ Thu (%):"
            Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'txtBoxSoKhachToiDa
            '
            Me.txtBoxSoKhachToiDa.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.txtBoxSoKhachToiDa.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtBoxSoKhachToiDa.Location = New System.Drawing.Point(414, 113)
            Me.txtBoxSoKhachToiDa.Margin = New System.Windows.Forms.Padding(40, 15, 40, 15)
            Me.txtBoxSoKhachToiDa.Name = "txtBoxSoKhachToiDa"
            Me.txtBoxSoKhachToiDa.Size = New System.Drawing.Size(294, 34)
            Me.txtBoxSoKhachToiDa.TabIndex = 2
            Me.txtBoxSoKhachToiDa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            '
            'TableLayoutPanel4
            '
            Me.TableLayoutPanel4.ColumnCount = 3
            Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
            Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
            Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
            Me.TableLayoutPanel4.Controls.Add(Me.btnCapNhat, 1, 0)
            Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
            Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 527)
            Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
            Me.TableLayoutPanel4.RowCount = 1
            Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
            Me.TableLayoutPanel4.Size = New System.Drawing.Size(1290, 102)
            Me.TableLayoutPanel4.TabIndex = 1
            '
            'btnCapNhat
            '
            Me.btnCapNhat.Dock = System.Windows.Forms.DockStyle.Fill
            Me.btnCapNhat.Location = New System.Drawing.Point(541, 25)
            Me.btnCapNhat.Margin = New System.Windows.Forms.Padding(25)
            Me.btnCapNhat.Name = "btnCapNhat"
            Me.btnCapNhat.Size = New System.Drawing.Size(208, 52)
            Me.btnCapNhat.TabIndex = 0
            Me.btnCapNhat.Text = "Cập Nhật"
            Me.btnCapNhat.UseVisualStyleBackColor = True
            '
            'frmThayDoiQuyDinh
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(1296, 725)
            Me.Controls.Add(Me.TableLayoutPanel1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
            Me.Name = "frmThayDoiQuyDinh"
            Me.Text = "frmThayDoiQuyDinh"
            Me.TableLayoutPanel1.ResumeLayout(False)
            Me.TableLayoutPanel2.ResumeLayout(False)
            Me.GroupBox1.ResumeLayout(False)
            Me.TableLayoutPanel3.ResumeLayout(False)
            Me.TableLayoutPanel3.PerformLayout()
            Me.TableLayoutPanel4.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub
        Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
        Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
        Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
        Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents txtBoxSoKhachToiDa As System.Windows.Forms.TextBox
        Friend WithEvents txtBoxTiLePhuThu As System.Windows.Forms.TextBox
        Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
        Friend WithEvents btnCapNhat As System.Windows.Forms.Button
    End Class
End Namespace